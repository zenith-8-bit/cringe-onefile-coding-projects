# AquaMesh — Urban Flood Digital Twin

A local-first, presentation-ready digital twin for the distributed hydrological sensing concept in `khetri doc(1).pdf`.

## Run
- Windows: double-click `run_windows.bat`
- Or run `python -m http.server 8000` in this folder and open `http://localhost:8000`
- No build step or cloud account is required.

## Included
- Live model: your isometric cutaway image with a canvas overlay (nodes, rain, flow, mesh hand-offs).
- Live simulated telemetry, event log, water-level trend, node health and risk score.
- Scenario controls: rainfall intensity, drain blockage, land overflow, river rise, sensor fault, node failure, internet loss.
- Node inspector with sensor readings and node temperature.
- CSV export of current telemetry.
- Local simulation values are deliberately synthetic and labelled SIMULATED.

## Hardware integration seam
The UI runs fully offline with deterministic/random demo data. To connect a Raspberry Pi later, edit `app.js`:
- `CONFIG.liveEndpoint` — endpoint returning a JSON snapshot.
- `CONFIG.telemetryEndpoint` — optional endpoint returning telemetry rows.
- `fetchLiveTelemetry()` — map your API response into the existing `state.nodes` shape.
A simple expected snapshot shape is documented in `integration/example-telemetry.json`.

Suggested real deployment: Raspberry Pi runs a local API (FastAPI/Flask), parses ESP32/LoRa packets, timestamps readings, stores them locally, computes risk, and exposes `/api/twin/state`. Keep the dashboard and Pi on the same LAN. This package does not claim to be connected to physical hardware.

## Model assumptions
This is a presentation simulator, not a calibrated hydraulic solver. Risk and downstream propagation are intentionally simplified for demonstration. The concept document's elevation chain is represented as Rain (14 m) → Drain (11 m) → Low Area (7 m) → River (4 m). Replace simulation logic with calibrated models and real sensor data for field use.

## Controls (no scrolling — five full-screen cards)
- `1`–`7` (numpad or top row): Twin / Nodes / Lab / Trend / Alerts / Infer / Sky
- `+` / `−` or `→` / `←`: shift to next / previous card
- `0` reset scenario · `Enter` (numpad) run storm · `.` (numpad) export CSV
- The isometric twin stays on screen in every card: full size on `1`, docked mini (with live vitals) on `2`–`7`. Click the mini twin or press `1` to expand it. Click a node on the full twin to open it in the Nodes card.
- Node positions on the image are set in `POS` inside `app.js` (image pixel coordinates, 1537×1023).

## Inference engine (card 6)
All outputs are numeric with a threshold colour (green / amber / red). Computed in `infer()` in `app.js`:
- Drain capacity used (% of the 12 cm alert level), rain headroom to overflow (mm/h), projected drain level at +30 min, time to overflow at the current rain ramp (min).
- Peak runoff Q = C · i · A (A = 0.8 ha demo catchment), runoff coefficient C from blended soil saturation.
- Flood probability (30 min, logistic on risk, projected rain, soil saturation and CAPE), early-warning index, lead time to risk 50, model confidence.
- Per-node sensor trust (battery, RSSI, packet loss, faults) and an archive analog match with its recorded outcome.
Assumptions: 1 simulation tick = 1 model minute; coefficients are demo values, not calibrated. Tune them in `infer()`.

## Weather, satellite and archive (card 7)
- **Live:** `fetchWx()` calls the Open-Meteo forecast API (no key): current conditions plus 3 days recorded and 2 days outlook of rain, cloud cover, CAPE and soil moisture. Set your site in `CONFIG.lat` / `CONFIG.lon`.
- **Satellite:** set `CONFIG.satelliteEndpoint` to a proxy for GPM IMERG / INSAT rainfall returning the shape in `integration/example-satellite.json`; it appears in the Sky card.
- **Archive:** `data/weather-archive.js` holds 168 h of hourly records and 5 storm events. It is SYNTHETIC sample data used when offline; replace it with your own exports (format described at the top of the file).
- "Drive twin with this rain" applies the current live (or archived) rainfall to the simulator.
